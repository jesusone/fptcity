<?php
	$params = array(
		array(
			"type" => "dropdown",
			"heading" => __("Filter Style",'fptcity'),
			"param_name" => "zo_filter_style",
			"value" => array(
                'Default' => '',
                'Dot Style' => 'style-2'
			),
            "group" => __("Template", 'fptcity')
		),

	);
